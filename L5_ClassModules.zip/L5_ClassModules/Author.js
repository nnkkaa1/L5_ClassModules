export class Author {
  #name;
  #birthYear;
  #isWriting;
  #deleted = false;

  constructor(name, birthYear, isWriting) {
    this.#name = name;
    this.#birthYear = birthYear;
    this.#isWriting = isWriting;
  }

  get name() {
    return this.#name;
  }

  set name(value) {
    if (typeof value !== "string" || value.trim() === "") {
      console.log("Имя должно быть непустой строкой");
      return;
    }
    this.#name = value;
  }

  get birthYear() {
    return this.#birthYear;
  }

  set birthYear(value) {
    if (typeof value !== "number" || value < 0) {
      console.log("Год рождения должен быть положительным числом");
      return;
    }
    this.#birthYear = value;
  }

  get isWriting() {
    return this.#isWriting;
  }

  set isWriting(value) {
    this.#isWriting = Boolean(value);
  }

  get isDeleted() {
    return this.#deleted;
  }

  show() {
    if (this.#deleted) {
      console.log("Объект удалён");
      return;
    }
    console.log("Автор: " + this.#name);
    console.log("Год рождения: " + this.#birthYear);
    console.log("Пишет сейчас: " + (this.#isWriting ? "да" : "нет"));
  }

  delete() {
    this.#name = undefined;
    this.#birthYear = undefined;
    this.#isWriting = undefined;
    this.#deleted = true;
  }

  copy() {
    return this;
  }

  static clone(author) {
    return new Author(author.name, author.birthYear, author.isWriting);
  }

  #finishCareer() {
    this.#isWriting = false;
  }

  retire() {
    this.#finishCareer();
  }
}
