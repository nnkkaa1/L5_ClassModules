import { Author } from "./Author.js";

export class Poet extends Author {
  #poemsCount;

  constructor(name, birthYear, isWriting, poemsCount) {
    super(name, birthYear, isWriting);
    this.#poemsCount = poemsCount;
  }

  get poemsCount() {
    return this.#poemsCount;
  }

  set poemsCount(value) {
    if (typeof value !== "number" || value < 0) {
      console.log("Количество стихов должно быть положительным числом");
      return;
    }
    this.#poemsCount = value;
  }

  retire() {
    console.log("У поэта нет этого метода");
  }

  show() {
    super.show();
    if (!this.isDeleted) {
      console.log("Количество стихов: " + this.#poemsCount);
    }
  }

  delete() {
    super.delete();
    this.#poemsCount = undefined;
  }

  copy() {
    return this;
  }

  static clone(poet) {
    return new Poet(poet.name, poet.birthYear, poet.isWriting, poet.poemsCount);
  }
}
