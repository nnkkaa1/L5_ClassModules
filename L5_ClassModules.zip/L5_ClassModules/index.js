import { Poet } from "./Poet.js";

const poets = [
  new Poet("Янка Купала", 1882, false, 1200),
  new Poet("Александр Пушкин", 1799, false, 800),
];

for (const poet of poets) {
  poet.show();
  console.log("");
}

const link = poets[0].copy();
console.log("copy: " + (link === poets[0]));

const clone = Poet.clone(poets[1]);
console.log("clone: " + (clone === poets[1]));
clone.show();

clone.poemsCount = 850;
clone.show();

clone.delete();
clone.show();
